# ricardaopersonal

Personal trainer com IA, em formato de conversa (estilo DM). Next.js + API da Anthropic, pronto para o Vercel.

## Rodar local
1. `npm install`
2. Copie `.env.example` para `.env.local` e coloque sua `ANTHROPIC_API_KEY`
3. `npm run dev` e abra http://localhost:3000

## Publicar no Vercel
1. Suba esta pasta para um repositório no GitHub
2. No Vercel: **Add New > Project**, importe o repositório
3. Em **Environment Variables**, cadastre `ANTHROPIC_API_KEY` (e, se quiser, `ANTHROPIC_MODEL`)
4. Clique em **Deploy**

## Personalizar
- Personalidade e regras do Ricardão: `lib/system-prompt.js`
- Visual: `app/globals.css`
- Chat: `app/page.js`
