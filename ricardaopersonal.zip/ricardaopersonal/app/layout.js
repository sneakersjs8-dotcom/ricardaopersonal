import "./globals.css";

export const metadata = {
  title: "ricardaopersonal",
  description: "Seu personal trainer no bolso.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}
