"use client";
import { useState, useRef, useEffect } from "react";

const SUGESTOES = ["Monta meu treino", "Treino em casa", "Dicas pra ganhar massa", "Como emagrecer sem sofrer"];

export default function Home() {
  const [msgs, setMsgs] = useState([
    { role: "assistant", content: "Fala! Sou o Ricardão, seu personal. Qual é seu objetivo hoje: ganhar massa, secar ou ganhar condicionamento?" },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs, loading]);

  async function send(text) {
    const content = (text ?? input).trim();
    if (!content || loading) return;
    const next = [...msgs, { role: "user", content }];
    setMsgs(next);
    setInput("");
    setLoading(true);
    try {
      const r = await fetch("/api/chat", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ messages: next }),
      });
      const d = await r.json();
      setMsgs([...next, { role: "assistant", content: r.ok ? d.reply : "Deu ruim aqui: " + (d.error || "tenta de novo.") }]);
    } catch {
      setMsgs([...next, { role: "assistant", content: "Sem conexão. Confere sua internet e manda de novo." }]);
    }
    setLoading(false);
  }

  return (
    <main className="app">
      <header className="top">
        <div className="avatar">R</div>
        <div>
          <strong>ricardaopersonal</strong>
          <span>Personal trainer · online</span>
        </div>
      </header>

      <section className="chat">
        {msgs.map((m, i) => (
          <div key={i} className={"row " + m.role}>
            <div className="bubble">{m.content}</div>
          </div>
        ))}
        {loading && <div className="row assistant"><div className="bubble typing"><i /><i /><i /></div></div>}
        {msgs.length === 1 && (
          <div className="chips">
            {SUGESTOES.map((s) => <button key={s} onClick={() => send(s)}>{s}</button>)}
          </div>
        )}
        <div ref={endRef} />
      </section>

      <footer className="bar">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send()}
          placeholder="Mensagem..."
          aria-label="Mensagem"
        />
        <button onClick={() => send()} disabled={!input.trim() || loading}>Enviar</button>
      </footer>
    </main>
  );
}
