import { SYSTEM_PROMPT } from "../../../lib/system-prompt";

export const maxDuration = 30;

export async function POST(req) {
  try {
    const { messages } = await req.json();
    if (!Array.isArray(messages) || messages.length === 0) {
      return Response.json({ error: "Mensagens inválidas." }, { status: 400 });
    }
    if (!process.env.ANTHROPIC_API_KEY) {
      return Response.json({ error: "ANTHROPIC_API_KEY não configurada." }, { status: 500 });
    }

    // Mantém só as últimas 20 mensagens e só os campos necessários
    const clean = messages
      .slice(-20)
      .map((m) => ({
        role: m.role === "assistant" ? "assistant" : "user",
        content: String(m.content || "").slice(0, 4000),
      }));

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5",
        max_tokens: 1000,
        system: SYSTEM_PROMPT,
        messages: clean,
      }),
    });

    const data = await r.json();
    if (!r.ok) {
      return Response.json({ error: data?.error?.message || "Erro na IA." }, { status: 502 });
    }
    const reply = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n");
    return Response.json({ reply });
  } catch (e) {
    return Response.json({ error: "Falha ao processar a mensagem." }, { status: 500 });
  }
}
